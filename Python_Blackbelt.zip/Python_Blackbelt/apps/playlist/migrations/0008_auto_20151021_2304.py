# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('playlist', '0007_auto_20151021_2255'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='playlist',
            table=None,
        ),
    ]
